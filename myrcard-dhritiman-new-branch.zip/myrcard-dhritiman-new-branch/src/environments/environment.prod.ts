export const environment = {
  production: true,
  buildname:'its in production',
  // baseUrl:'https://praveeng-1002.herokuapp.com/',
  // soapUrl:'https://praveeng-1002.herokuapp.com/'
  baseUrl:'/',
  soapUrl:'/'
};
