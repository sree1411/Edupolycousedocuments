export enum TransactionStatus {
    ctsCleared="CLEARED",
    ctsDeclined="DECLINED",
    ctsReversed="REVERSED"
}