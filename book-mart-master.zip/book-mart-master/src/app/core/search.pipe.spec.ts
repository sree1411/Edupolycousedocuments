import { SearchPipe } from './search.pipe';

describe('CategoryPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchPipe();
    expect(pipe).toBeTruthy();
  });
});
